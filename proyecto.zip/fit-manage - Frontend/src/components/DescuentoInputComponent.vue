<template>
    <ion-item>
      <ion-label>Porcentaje de Descuento (%)</ion-label>
      <ion-input
        v-model="modelValue"
        type="number"
        placeholder="Ingresa el porcentaje"
        min="0"
        max="100"
        step="0.01"
      ></ion-input>
    </ion-item>
  </template>
  
  <script>
  export default {
    props: {
      modelValue: {
        type: Number,
        required: true,
      },
    },
    emits: ["update:modelValue"],
  };
  </script>