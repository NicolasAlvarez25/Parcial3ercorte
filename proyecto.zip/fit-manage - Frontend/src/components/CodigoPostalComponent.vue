<template>
    <div class="codigo-postal">
      <label for="codigo-postal">Código Postal:</label>
      <input
        type="text"
        id="codigo-postal"
        v-model="codigoPostal"
        @input="actualizarCodigoPostal"
        maxlength="10"
        placeholder="Ingresa tu código postal"
      />
    </div>
  </template>
  
  <script>
  export default {
    props: {
      value: {
        type: String,
        default: "",
      },
    },
    data() {
      return {
        codigoPostal: this.value,
      };
    },
    methods: {
      actualizarCodigoPostal() {
        this.$emit("input", this.codigoPostal);
      },
    },
  };
  </script>
  
  <style scoped>
  .codigo-postal {
    margin: 1rem 0;
  }
  </style>
  