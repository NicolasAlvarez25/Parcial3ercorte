<!-- Membresías.vue -->
<template>
  <ion-content>
    <ion-loading :is-open="loading" message="Inscribiendo ..."></ion-loading>
    <ion-alert
      v-if="showAlert"
      :is-open="showAlert"
      onDidDismiss="() => (showAlert = false)"
      header="Cargando"
      message="Por favor, espera mientras se cargan los datos."
    ></ion-alert>
    <div class="cards-container">
      <ion-card v-for="(plan, index) in plans" :key="plan.id">
        <ion-card-header>
          <ion-card-subtitle>Plan <span class="bold">{{ plan.nombrePlan }}</span></ion-card-subtitle>
          <ion-card-title>{{ formatCurrency(plan.precio) }}</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <p>{{ plan.descripcion }}</p>
          <p>Tipo de plan: {{ plan.tipo }}</p>
          <div v-if="plan.showBenefits" class="benefits-list">
            <ul>
              <li v-for="(benefit, i) in benefits" :key="i">
                <p>{{ benefit.name }}</p>
                <ion-icon v-if="benefit.plans[index]" icon="checkmark-circle" class="check"></ion-icon>
              </li>
            </ul>
          </div>
        </ion-card-content>
        <ion-button expand="block" color="warning" class="action-button" @click="openMembershipModal(plan.id)">
          Comienza ahora
        </ion-button>
        <ion-item lines="none" button @click="toggleBenefits(index)">
          <ion-label class="show-benefits">{{ plan.showBenefits ? 'Mostrar menos' : 'Mostrar beneficios' }}</ion-label>
          <ion-icon :icon="plan.showBenefits ? 'chevron-up-outline' : 'chevron-down-outline'" slot="end"></ion-icon>
        </ion-item>
      </ion-card>
    </div>
    <ion-modal :is-open="isModalOpen" @didDismiss="closeModal" class="custom-modal">
      <ion-card class="modal-content">
        <ion-card-header class="modal-header">
          <ion-card-title>Selecciona la duración de la membresía</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <div v-for="(duracion, index) in duraciones" :key="index" class="duration-option">
            <ion-item button @click="selectDuration(duracion)">
              <ion-label>{{ duracion.meses }} meses - {{ formatCurrency(duracion.valor) }}</ion-label>
              <p class="observacion">{{ duracion.observacion }}</p>
            </ion-item>
          </div>
        </ion-card-content>
        <ion-button expand="full" color="medium" @click="closeModal">Cerrar</ion-button>
      </ion-card>
    </ion-modal>
  </ion-content>
</template>

<script>
import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonIcon,
  IonItem,
  IonLabel,
  IonModal,
  IonLoading,
  IonAlert,
} from '@ionic/vue';
import { checkmarkCircle, chevronDownOutline, chevronUpOutline } from 'ionicons/icons';
import axios from 'axios';
import { useRouter } from 'vue-router';
import { API_BASE_URL } from '@/config';

export default {
  components: {
    IonButton,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    IonModal,
    IonLoading,
    IonAlert,
  },
  data() {
    return {
      loading: false,  // Estado de carga
      plans: [],
      showAlert: false,  // Control para mostrar el IonAlert
      benefits: [
        { name: "Acceso ilimitado a más de 1500 sedes de la red", plans: [true, true, true] },
        { name: "Entrena hasta con 5 amigos al mes", plans: [true, false, false] },
        { name: "Smart Spa (Relájate en los sillones de masajes)", plans: [true, false, false] },
        { name: "Smart Fit App (Tu plan de entrenamiento personalizado)", plans: [true, true, true] },
        { name: "Smart Vital (Seguimiento a tu progreso)", plans: [true, true, true] },
        { name: "Smart Fit Go (Entrenamientos en línea)", plans: [true, true, true] },
        { name: "Clases grupales con profesores", plans: [true, true, true] },
        { name: "Acceso a todas las áreas de la sede", plans: [true, true, false] },
      ],
      duraciones: [
        { meses: 1, valor: 69900, observacion: 'Duración corta ideal para probar el servicio.' },
        { meses: 3, valor: 199900, observacion: 'Descuento aplicado por tres meses.' },
        { meses: 6, valor: 359900, observacion: 'Ahorra más con seis meses de membresía.' },
        { meses: 12, valor: 599900, observacion: 'Mejor oferta por un año completo.' },
      ],
      icons: {
        check: checkmarkCircle,
        chevronDown: chevronDownOutline,
        chevronUp: chevronUpOutline,
      },
      isModalOpen: false,
      selectedPlanId: null,
    };
  },
  created() {
    this.fetchPlans();
  },
  methods: {
    async fetchPlans() {
      this.showAlert = true;
      try {
        const response = await axios.get(`${API_BASE_URL}/planes`);
        if (response.status === 200) {
          this.plans = response.data;
        } else {
          console.error('Error al obtener los planes');
        }
      } catch (error) {
        console.error('Error en la solicitud:', error);
      } finally {
        this.showAlert = false;
      }
    },
    toggleBenefits(index) {
      this.plans[index].showBenefits = !this.plans[index].showBenefits;
    },
    formatCurrency(value) {
      return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(value);
    },
    openMembershipModal(planId) {
      this.selectedPlanId = planId;
      this.isModalOpen = true;
    },
    closeModal() {
      this.isModalOpen = false;
    },
    async selectDuration(duracion) {
      this.loading = true; // Mostrar el IonLoading
      const clienteId = localStorage.getItem('clienteId');
      if (!clienteId) {
        alert('Por favor, inicia sesión primero.');
        this.closeModal();
        this.loading = false;
        return;
      }
      
      const dataToSend = {
        clienteId,
        planId: this.selectedPlanId,
        mesesDuracion: duracion.meses,
        valor: duracion.valor,
      };

      try {
        const response = await axios.post(`${API_BASE_URL}/membresias/crear`, null, {
          params: dataToSend,
        });

        if (response.status === 201) {
          this.closeModal();
          this.$router.push({
            path: '/Facturas',
            query: {
              planId: this.selectedPlanId,
              valor: duracion.valor,
              meses: duracion.meses,
            },
          });
        } else {
          console.error('Error en la creación de membresía');
        }
      } catch (error) {
        console.error('Error en la solicitud:', error);
      } finally {
        this.loading = false; // Ocultar el IonLoading
      }
    },
  },
};
</script>

<style scoped>
.cards-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}
.bold {
  font-weight: bold;
}
.action-button {
  margin: 10px 0;
}
.benefits-list {
  margin-top: 10px;
}
.observacion {
  font-size: 0.85em;
  color: #666;
}
.custom-modal .modal-content {
  padding: 20px;
}
.show-benefits {
  color: #555;
}
</style>
