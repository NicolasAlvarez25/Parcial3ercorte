<template>
  <ion-content>
    <div class="schedule-container">
      <h1>Horario de <span class="highlight">clases grupales</span></h1>
      <p>Escoge un día</p>
      
      <!-- Selección de días de la semana -->
      <div class="days-selector">
        <ion-button
          v-for="(day, index) in days"
          :key="index"
          :color="selectedDay === day ? 'dark' : 'light'"
          @click="selectDay(day)"
          expand="block"
          fill="solid"
        >
          {{ day }}
        </ion-button>
      </div>
      
      <!-- Horario de Clases -->
      <div class="schedule-list">
        <div class="class-row" v-for="(classItem, index) in getClassesForDay" :key="index">
          <span class="time">{{ classItem.time }}</span>
          <span class="class-name">{{ classItem.name }}</span>
          <span class="duration">{{ classItem.duration }}</span>
        </div>
      </div>

      <ion-button expand="block" color="warning" class="subscribe-button" href="/tabs/planes">
        ¡Inscríbete ahora!
      </ion-button>
    </div>
  </ion-content>
</template>
<script>
import { IonButton } from '@ionic/vue';

export default {
  components: {
    IonButton,
  },
  data() {
    return {
      days: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
      selectedDay: "MAR",
      classes: [
        { name: "Smart Cycling", duration: "45min" },
        { name: "Smart Step", duration: "45min" },
        { name: "Smart Abdomen", duration: "45min" },
        { name: "Smart Funcional", duration: "45min" },
        { name: "SMART RTS", duration: "45min" },
        { name: "Smart Estacionamiento", duration: "45min" },
        { name: "Smart Rumba", duration: "45min" },
      ],
      baseTimes: [
        "06:00", "06:45", "07:30", "08:15", "09:00",
        "10:15", "11:00", "16:15", "17:00", "17:45",
        "18:30", "19:15", "20:00"
      ],
    };
  },
  computed: {
    getClassesForDay() {
      const dayIndex = this.days.indexOf(this.selectedDay);
      return this.baseTimes.map((time, index) => {
        // Alternar clase basada en el día y el índice
        const classItem = this.classes[(index + dayIndex) % this.classes.length];
        return { time, ...classItem };
      });
    },
  },
  methods: {
    selectDay(day) {
      this.selectedDay = day;
    },
  },
};
</script>
<style>
.schedule-container {
  padding: 16px;
  text-align: center;
}

h1 {
  font-size: 1.5em;
  margin-bottom: 10px;
}

.highlight {
  color: #ffaf0f;
}

.days-selector {
  display: flex;
  justify-content: center;
  gap: 4px;
  margin-bottom: 16px;
}

.schedule-list {
  border-top: 1px solid #ddd;
}

.class-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 0;
  border-bottom: 1px solid #ddd;
  font-weight: bold;
}

.time {
  font-size: 0.9em;
  color: #666;
}

.class-name {
  color: #333;
  flex: 1;
  text-align: left;
  margin-left: 10px;
}

.duration {
  color: #666;
  font-size: 0.9em;
}

.subscribe-button {
  margin-top: 20px;
  background-color: #ffaf0f;
  color: #fff;
}
</style>