<template>
  <ion-page>
    <ion-content>
      <div class="background-container"></div>
      <BotonatrasComponent href="/home"> </BotonatrasComponent>

      <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; position: relative;">
        <ImagenComponent id="miImagen" imageUrl="/resources/logo.png" altText="imagen" class="logo-image" />
      </div>

      <ion-card class="custom-rounded">
        <div class="segment">
          <ion-segment v-model="selectedOption">
            <ion-segment-button color="light" value="login">
              <ion-label>Login</ion-label>
            </ion-segment-button>
            <ion-segment-button color="secondary" value="registro">
              <ion-label>Sign Up</ion-label>
            </ion-segment-button>
          </ion-segment>
        </div>

        <!-- Mostrar el indicador de carga si isLoading es verdadero -->
        <div v-if="selectedOption === 'login'" class="input">
          <ion-item>
            <ImputComponent class="texto" id="email" name="email" type="email" label="E-mail:" placeholder="email@domain.com" label-placement="floating" counter="true" v-model="email">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ImputComponent class="texto" id="Password" name="Password" type="password" placeholder="Password" label="Password:" label-placement="floating" v-model="password">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ButtonComponent id="login" value="login" fill="solid" color="medium" expand="block" size="large" class="custom-button-width" @click="validarCredenciales">
            </ButtonComponent>
          </ion-item>
        </div>

        <div v-else-if="selectedOption === 'registro'" class="input">
          <ion-item>
            <ImputComponent class="texto" id="nombre" name="nombre" label="Nombre: " placeholder="Nombres" label-placement="floating" counter="true" v-model="nombre">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ImputComponent class="texto" id="apellido" name="apellido" label="Apellido: " placeholder="Apellidos" label-placement="floating" counter="true" v-model="apellido">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ImputComponent class="number" id="telefono" name="telefono" label="Teléfono: " placeholder="Teléfono" label-placement="floating" counter="true" v-model="telefono">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ImputComponent class="texto" id="Direccion" name="Direccion" label="Dirección: " placeholder="Dirección" label-placement="floating" counter="true" v-model="direccion">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ImputComponent class="number" id="Documento" name="Documento" label="Documento: " placeholder="Documento" label-placement="floating" counter="true" v-model="documento">
            </ImputComponent>
          </ion-item>

          <ion-item>
            <ion-label position="floating">Fecha de Nacimiento:</ion-label>
            <ion-input type="date" v-model="fechaNacimiento"></ion-input>
          </ion-item>

          <ion-item>
            <ImputComponent class="texto" id="email" name="email" type="email" label="E-mail: " placeholder="email@domain.com" label-placement="floating" counter="true" v-model="email">
            </ImputComponent>
          </ion-item>
          <ion-item>
            <ImputComponent class="texto" id="Password" name="Password" type="password" placeholder="Password" label="Password: " label-placement="floating" v-model="password">
            </ImputComponent>
          </ion-item>

          <!-- Campo de Código Postal -->
          <ion-item>
            <ImputComponent class="number" id="codigoPostal" name="codigoPostal" label="Código Postal: " placeholder="Código Postal" label-placement="floating" counter="true" v-model="codigoPostal">
            </ImputComponent>
          </ion-item>

          <ion-item>
            <ButtonComponent id="registrar" value="registrar" fill="solid" color="medium" expand="block" size="large" class="custom-button-width" @click="Registrar">
            </ButtonComponent>
          </ion-item>
        </div>
      </ion-card>
      <ion-alert
        v-if="isLoading"
        is-open="isLoading"
        on-did-dismiss="isLoading = false"
        header="Cargando"
        message="Por favor, espere..."
        css-class="loading-alert"
        class="loading-spinner"
      ></ion-alert>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { IonPage, IonContent, IonSegment, IonSegmentButton, IonItem, IonLabel, IonInput } from '@ionic/vue';
import ButtonComponent from '@/components/ButtonComponent.vue';
import ImagenComponent from '@/components/ImagenComponent.vue';
import ImputComponent from '@/components/ImputComponent.vue';
import BotonatrasComponent from '@/components/BotonatrasComponent.vue';
import axios from 'axios';
import { ref } from 'vue';
import { API_BASE_URL } from '@/config';

const selectedOption = ref('login');
const nombre = ref('');
const apellido = ref('');
const telefono = ref('');
const direccion = ref('');
const documento = ref('');
const fechaNacimiento = ref('');
const email = ref('');
const password = ref('');
const codigoPostal = ref(''); // Nueva variable para el Código Postal
const isLoading = ref(false);

// Función para validar credenciales
const validarCredenciales = async () => {
  isLoading.value = true;
  try {
    const response = await axios.get(`${API_BASE_URL}/clientes/validar/${email.value}/${password.value}`);
    isLoading.value = false;

    if (response.data.authenticated) {
      localStorage.setItem('clienteId', response.data.id);
      window.location.href = '/tabs/planes';
    } else {
      alert('Usuario o contraseña incorrecto');
    }
  } catch (error) {
    isLoading.value = false;
    console.error(error);
    alert('Error al validar credenciales');
  }
}

// Función para registrar un nuevo cliente
const Registrar = async () => {
  isLoading.value = true;
  try {
    const response = await axios.post(`${API_BASE_URL}/clientes/registro`, {
      nombre: nombre.value,
      apellido: apellido.value,
      telefono: telefono.value,
      direccion: direccion.value,
      documento: documento.value,
      fechaNacimiento: fechaNacimiento.value,
      email: email.value,
      password: password.value,
      codigoPostal: codigoPostal.value, // Agregar el código postal al registro
    });
    isLoading.value = false;

    if (response.data) {
      isLoading.value = true;
      nombre.value = '';
      apellido.value = '';
      telefono.value = '';
      direccion.value = '';
      documento.value = '';
      fechaNacimiento.value = '';
      email.value = '';
      password.value = '';
      codigoPostal.value = ''; // Limpiar el código postal después del registro
    } else {
      alert('Error al registrar el usuario');
    }
  } catch (error) {
    isLoading.value = false;
    console.error(error);
    alert('Error al registrar el usuario');
  }
};
</script>

<style scoped>
/* Reducir padding en ion-content */
ion-content {
  --padding-top: 10px;
}

/* Mover ion-card hacia arriba */
ion-card.custom-rounded {
  margin-top: 10px;
}

/* Mover la imagen hacia arriba */
.logo-container {
  margin-top: -20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.logo-image {
  width: 200px;
  height: auto;
  margin-top: -10px;
}

/* Ajuste del tamaño de los iconos */
ion-icon {
  font-size: 2em;
}

/* Estilo del indicador de carga */
.loading-spinner {
  margin-top: 20px;
}
.loading-alert {
  --background: rgba(0, 0, 0, 0.75);
  --color: white;
}
</style>
