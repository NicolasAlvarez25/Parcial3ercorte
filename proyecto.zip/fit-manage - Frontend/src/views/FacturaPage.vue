<template>
    <ion-content>
      <ion-card v-if="!loading">
        <ion-card-header>
          <ion-card-title>Factura de Membresía</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <p><strong>Cliente:</strong> {{ cliente.nombre }}</p>
          <p><strong>Documento:</strong> {{ cliente.documento }}</p>
          <p><strong>Plan:</strong> {{ plan.nombrePlan }}</p>
          <p><strong>Descripción:</strong> {{ plan.descripcion }}</p>
          <p><strong>Duración:</strong> {{ meses }} meses</p>
          <p><strong>Valor:</strong> {{ formatCurrency(valor) }}</p>
          <ion-button expand="full" color="primary" @click="showPaymentModal = true">
            Seleccionar Forma de Pago
          </ion-button>
        </ion-card-content>
      </ion-card>
  
      <ion-loading :is-open="loading" message="Cargando datos..."></ion-loading>
  
      <!-- Modal para Selección de Método de Pago -->
      <ion-modal :is-open="showPaymentModal">
        <ion-page>
          <ion-header>
            <ion-toolbar>
              <ion-title>Selecciona tu Forma de Pago</ion-title>
              <ion-buttons slot="end">
                <ion-button @click="showPaymentModal = false">Cerrar</ion-button>
              </ion-buttons>
            </ion-toolbar>
          </ion-header>
          <ion-content :fullscreen="true" class="ion-padding">
            <div class="payment-options">
              <div class="payment-option" @click="selectPayment('nequi')">
                <img src="https://brandemia.org/contenido/subidas/2023/10/nequi-nuevo-logotipo-1200x670.jpg" alt="Nequi" />
                <p>Nequi</p>
              </div>
              <div class="payment-option" @click="selectPayment('bancolombia')">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSguSHX68Y-U-BTTewSjgz2Ok1qT8WGRzebiA&s" alt="Bancolombia" />
                <p>Bancolombia</p>
              </div>
              <div class="payment-option" @click="selectPayment('credit-card')">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvjXzkWXWwetIamP4q_CjFIaEz4EOAPHwVAQ&s" alt="Tarjeta de Crédito" />
                <p>Tarjeta de Crédito</p>
              </div>
              <div class="payment-option" @click="selectPayment('debit-card')">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStsBFerwLCkZXpEcmMfA2IeqV_hNXzmqNRbA&s" alt="Tarjeta de Débito" />
                <p>Tarjeta de Débito</p>
              </div>
            </div>
            <ion-button expand="full" color="primary" @click="confirmPayment">
              Confirmar Método de Pago
            </ion-button>
          </ion-content>
        </ion-page>
      </ion-modal>
    </ion-content>
  </template>
  
  <script>
  import { IonCard, IonCardContent, IonCardHeader, IonCardTitle, IonModal, IonPage, IonHeader, IonToolbar, IonTitle, IonButtons, IonButton, IonLoading } from '@ionic/vue';
  import axios from 'axios';
  import { API_BASE_URL } from '@/config';
  
  export default {
    components: {
      IonCard,
      IonCardContent,
      IonCardHeader,
      IonCardTitle,
      IonModal,
      IonPage,
      IonHeader,
      IonToolbar,
      IonTitle,
      IonButtons,
      IonButton,
      IonLoading
    },
    data() {
      return {
        planId: null,
        valor: null,
        meses: null,
        plan: {
          nombrePlan: '',
          descripcion: '',
        },
        cliente: {
          nombre: '',
          documento: '',
        },
        showPaymentModal: false,
        selectedPaymentMethod: null,
        loading: true, // Estado de carga
      };
    },
    created() {
      this.planId = this.$route.query.planId;
      this.valor = this.$route.query.valor;
      this.meses = this.$route.query.meses;
      this.fetchFacturaDetails();
    },
    methods: {
      async fetchFacturaDetails() {
        try {
          const clienteId = localStorage.getItem('clienteId');
          const planResponse = await axios.get(`${API_BASE_URL}/planes/${this.planId}`);
          if (planResponse.status === 200) {
            this.plan = {
              nombrePlan: planResponse.data.nombrePlan,
              descripcion: planResponse.data.descripcion,
            };
          }
          const clienteResponse = await axios.get(`${API_BASE_URL}/clientes/obtener/${clienteId}`);
          if (clienteResponse.status === 200) {
            this.cliente = {
              nombre: clienteResponse.data.nombre,
              documento: clienteResponse.data.documento,
            };
          }
        } catch (error) {
          console.error('Error al obtener los detalles de la factura:', error);
        } finally {
          this.loading = false; // Oculta el indicador de carga una vez que se completan las solicitudes
        }
      },
      selectPayment(method) {
        this.selectedPaymentMethod = method;
      },
      async confirmPayment() {
        if (this.selectedPaymentMethod) {
          const paymentConfirmed = await this.savePayment();
          if (paymentConfirmed) {
            alert(`Pago registrado con éxito con el método: ${this.selectedPaymentMethod}`);
            this.showPaymentModal = false;
            window.location.href = '/tabs/clases';
          }
        } else {
          alert('Por favor, selecciona un método de pago.');
        }
      },
      async savePayment() {
        try {
          const clienteId = localStorage.getItem('clienteId'); // Asumiendo que guardas el clienteId en el localStorage
          const paymentData = {
            cliente: { id: clienteId }, // Asegúrate de que el cliente tenga un campo ID
            fechaEmision: new Date(),
            montoTotal: this.valor,
            metodoPago: this.selectedPaymentMethod,
            estado: 'Pagado', // Puedes ajustar esto según sea necesario
          };
          const response = await axios.post(`${API_BASE_URL}/facturas`, paymentData);
          return response.status === 201; // Retorna true si la factura se creó exitosamente
        } catch (error) {
          console.error('Error al guardar el pago:', error);
          return false; // Retorna false si hubo un error
        }
      },
      formatCurrency(value) {
        return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(value);
      }
    }
  };
  </script>
  
  <style scoped>
  .card-content p {
    margin: 10px 0;
  }
  
  .payment-options {
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 20px;
  }
  
  .payment-option {
    text-align: center;
    width: 100px;
    margin: 10px;
    cursor: pointer;
    transition: transform 0.2s;
  }
  
  .payment-option:hover {
    transform: scale(1.05);
  }
  
  .payment-option img {
    width: 80px;
    height: 80px;
    object-fit: contain;
  }
  
  ion-button {
    margin-top: 20px;
  }
  </style>
  