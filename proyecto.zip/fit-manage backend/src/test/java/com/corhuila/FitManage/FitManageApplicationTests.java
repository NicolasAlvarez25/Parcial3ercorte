package com.corhuila.FitManage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
